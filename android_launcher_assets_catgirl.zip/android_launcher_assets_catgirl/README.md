# Android Launcher Icon - Catgirl Head (Adaptive Icon)

这是一套**无需 Android Studio** 的启动图标资源，直接放进 `app/src/main/res` 就能用：
- `values/ic_launcher_background.xml`：背景色
- `drawable/ic_launcher_foreground.xml`：前景（VectorDrawable，猫娘大头照，纯色扁平风）
- `mipmap-anydpi-v26/ic_launcher.xml`：Adaptive icon
- `mipmap-anydpi-v26/ic_launcher_round.xml`：Adaptive icon（圆形）

> 你的 `AndroidManifest.xml` 已经引用：
> - `android:icon="@mipmap/ic_launcher"`
> - `android:roundIcon="@mipmap/ic_launcher_round"`
> 所以把这些文件加入后，CI 的 `processDebugResources` 就会通过。

## 直接拷贝
把本目录中的 `app/` 目录合并到你的工程根目录即可。

## Git 命令（示例）
```bash
# 在项目根目录运行：
git checkout -b feature/add-catgirl-icon
mkdir -p app/src/main/res/{values,drawable,mipmap-anydpi-v26}

# 拷贝四个文件（按你自己的路径调整）
cp -r app/src/main/res/values/ic_launcher_background.xml ./app/src/main/res/values/
cp -r app/src/main/res/drawable/ic_launcher_foreground.xml ./app/src/main/res/drawable/
cp -r app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml ./app/src/main/res/mipmap-anydpi-v26/
cp -r app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml ./app/src/main/res/mipmap-anydpi-v26/

git add app/src/main/res/values/ic_launcher_background.xml         app/src/main/res/drawable/ic_launcher_foreground.xml         app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml         app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml
git commit -m "feat(icon): add adaptive launcher icon (catgirl headshot)"
git push -u origin feature/add-catgirl-icon
```

## 可选：修改主题色
- 背景色在 `values/ic_launcher_background.xml`：`#ECE8FF`
- 头发颜色在前景矢量 `ic_launcher_foreground.xml` 的 `#6C63FF`（可以全局替换）。

## 版权与使用
本图标由助手自动生成，授权你在本项目中使用与修改。
